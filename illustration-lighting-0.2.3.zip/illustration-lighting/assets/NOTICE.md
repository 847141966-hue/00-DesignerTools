`face-data.js` is a front-view depth and normal projection derived from the MediaPipe
canonical face mesh (Google LLC and contributors), under Apache License 2.0. It
contains baked normals and depth with eye and chin landmarks for alignment.
No appearance or photographic texture is used.

Source revision 727e43fcb7c7477f3fdf88c0498588349baaf2e5.
[Canonical face mesh](https://github.com/google-ai-edge/mediapipe/blob/727e43fcb7c7477f3fdf88c0498588349baaf2e5/mediapipe/modules/face_geometry/data/canonical_face_model.obj)
