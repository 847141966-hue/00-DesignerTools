import sys, base64, textwrap, json
import numpy as np

def read_obj(path):
    vertices, triangles = [], []
    for line in open(path, encoding='utf-8'):
        tokens = line.split()
        if tokens and tokens[0] == 'v':
            vertices.append([float(x) for x in tokens[1:4]])
        elif tokens and tokens[0] == 'f':
            triangles.append([int(x.split('/')[0]) - 1 for x in tokens[1:]])
    return np.array(vertices), np.array(triangles)

def bake(vertices, faces, scale, width, height):
    points = vertices.copy()
    points[:,0] = points[:,0] * scale + width / 2
    points[:,1] = -points[:,1] * scale + height * .47
    points[:,2] *= scale
    smooth = np.zeros_like(vertices)
    for face in faces:
        a, b, c = points[face]
        normal = -np.cross(b-a, c-a)
        np.add.at(smooth,face,normal)
    smooth /= np.maximum(1e-8, np.linalg.norm(smooth, axis=1, keepdims=True))
    depth = np.full((height,width), -np.inf)
    normal = np.zeros((height,width,3))
    for face in faces:
        a,b,c = points[face]
        x0,y0 = np.floor(np.minimum(np.minimum(a,b),c)[:2]).astype(int)
        x1,y1 = np.ceil(np.maximum(np.maximum(a,b),c)[:2]).astype(int)
        y,x = np.mgrid[y0:y1, x0:x1] + .5
        ab, ac = b-a, c-a
        det = ab[0]*ac[1]-ab[1]*ac[0]
        if abs(det) < 1e-6:
            continue
        u = ((x-a[0])*ac[1]-(y-a[1])*ac[0])/det
        v = (ab[0]*(y-a[1])-ab[1]*(x-a[0]))/det
        z = a[2] + u*ab[2] + v*ac[2]
        section = depth[y0:y1,x0:x1]
        closer = (u>=0)&(v>=0)&(u+v<=1)&(z>section)
        section[closer] = z[closer]
        n = smooth[face[0]] + u[...,None]*(smooth[face[1]]-smooth[face[0]]) + v[...,None]*(smooth[face[2]]-smooth[face[0]])
        n /= np.maximum(1e-8,np.linalg.norm(n, axis=2, keepdims=True))
        normal[y0:y1,x0:x1][closer] = n[closer]
    return points, depth, normal

def pack(points, depth, normal, output):
    visible = np.isfinite(depth)
    z_min, z_max = depth[visible].min(), depth[visible].max()
    packed = np.zeros((*depth.shape,4), dtype='uint8')
    packed[visible,:3] = np.round((normal[visible] * .5 + .5) * 255)
    packed[visible,3] = np.round(1+(depth[visible]-z_min)/(z_max-z_min)*254)
    ys, xs = np.where(visible)
    x0,x1,y0,y1=xs.min(),xs.max()+1,ys.min(),ys.max()+1
    eyes = (points[159]+points[145])/2, (points[386]+points[374])/2
    landmarks = np.array([*eyes,points[152]])[:,:2] - [x0,y0]
    meta = dict(width=int(x1-x0),height=int(y1-y0),depthSpan=round(z_max-z_min,4),
                landmarks=np.round(landmarks,3).tolist())
    data = base64.b64encode(packed[y0:y1,x0:x1].tobytes()).decode('ascii')
    with open(output,'w',encoding='utf-8') as out:
        out.write('// Baked from the MediaPipe canonical face. See assets/NOTICE.md.\n')
        out.write('module.exports = '+json.dumps(meta)[:-1]+',\n  "data": [\n')
        for part in textwrap.wrap(data,112):
            out.write("    '"+part+"',\n")
        out.write("  ].join('')\n}\n")

if __name__ == '__main__':
    mesh = read_obj(sys.argv[1])
    pack(*bake(*mesh, 11, 200, 224), sys.argv[2])
