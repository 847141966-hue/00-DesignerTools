const { prepareSurface, visibility } = require('./surface.js')

const clamp = value => Math.max(0, Math.min(1, value))

function smooth(lo, hi, value) {
  const t = clamp((value - lo) / (hi - lo))
  return t * t * (3 - 2 * t)
}

function alpha(image, x, y) {
  if (x < 0 || x >= image.width || y < 0 || y >= image.height) return 0
  return image.components === 4 ? image.pixels[(y * image.width + x) * 4 + 3] / 255 : 1
}

function shrink(image, scale) {
  const width = Math.max(1, Math.round(image.width * scale))
  const height = Math.max(1, Math.round(image.height * scale))
  const pixels = new Uint8Array(width * height * image.components)
  for (let y = 0; y < height; y++) {
    const sourceY = Math.min(image.height - 1, Math.floor((y + 0.5) / scale))
    for (let x = 0; x < width; x++) {
      const sourceX = Math.min(image.width - 1, Math.floor((x + 0.5) / scale))
      const src = (sourceY * image.width + sourceX) * image.components
      const dest = (y * width + x) * image.components
      for (let c = 0; c < image.components; c++) pixels[dest + c] = image.pixels[src + c]
    }
  }
  return { ...image, pixels, width, height,
    left: Math.round(image.left * scale), top: Math.round(image.top * scale) }
}

function prepareLight(light) {
  const x = (light.x - 0.5) * 3.6
  const y = (light.y - 0.5) * 3.6
  const z = (light.depth ?? 0.7) * 2.2 - 0.95
  const length = Math.max(0.0001, Math.hypot(x, y, z))
  const direction = { x: x / length, y: y / length, z: z / length }
  const half = Math.max(0.001, Math.hypot(direction.x, direction.y, direction.z + 1))
  return {
    ...light, ...direction, u: light.x, v: light.y, horizontal: Math.hypot(x, y) / length,
    hx: direction.x / half, hy: direction.y / half, hz: (direction.z + 1) / half
  }
}

function volumeLight(surface, light, normal, x, y, dim, settings, result) {
  result.diffuse = 0
  result.specular = 0
  result.rim = 0
  if (!light.strength) return
  const facing = normal.x * light.x + normal.y * light.y + normal.z * light.z
  const feather = 0.035 + settings.softness * 0.31
  const lambert = smooth(-feather, feather + 0.44, facing) * (0.34 + 0.66 * clamp(facing))
  if (lambert > 0.004) {
    const exposed = visibility(surface, normal, light, x, y, dim, settings.softness)
    result.diffuse = lambert * exposed * light.strength
    const halfFacing = clamp(normal.x * light.hx + normal.y * light.hy + normal.z * light.hz)
    const gloss = 9 + (1 - settings.softness) * 50
    result.specular = Math.pow(halfFacing, gloss) * exposed * clamp(facing * 1.7) *
      light.strength * (settings.gloss ?? 0.28)
  }
  const grazing = Math.pow(1 - clamp(normal.z), 2.3)
  result.rim = clamp(facing * 1.6) * grazing * settings.rim * light.strength
}

function atmosphere(light, u, v, aspectX, aspectY, edgeX, edgeY, settings, result) {
  result.diffuse = 0
  result.specular = 0
  result.rim = 0
  if (!light.strength) return
  const distance = Math.hypot((light.u - u) * aspectX, (light.v - v) * aspectY)
  result.diffuse = (1 - smooth(0.04, 0.44 + settings.softness * 0.75, distance)) *
    light.strength * (1 - settings.rim * 0.45)
  result.rim = clamp(edgeX * light.x + edgeY * light.y) * settings.rim * light.strength
}

function lightOpacity(light) {
  return clamp(light.diffuse * 0.90 + light.specular * 1.6 + light.rim * 0.87)
}

function channelLit(base, pigment, light, opacity, volume) {
  if (!opacity) return base
  if (!volume) return (base + (255 - base) * 0.42) * (0.55 + 0.45 * pigment / 255)
  const diffuse = (base + (255 - base) * 0.61) * (0.50 + 0.50 * pigment / 255)
  const shine = clamp((light.specular * 1.6 + light.rim * 0.54) / opacity)
  return diffuse + (pigment - diffuse) * shine
}

function render(source, guide, settings, { start = 0, rows = source.height, preview = false } = {}) {
  const { width, height, components, pixels } = source
  const shape = settings.mode === 'shape'
  if (shape && !guide) throw new Error('先对齐头像或读取形体图。')
  const surface = shape ? prepareSurface(source, guide, settings.relief, settings.maskSkin) : null
  const lights = settings.lights.map(prepareLight)
  const dim = Math.min(width, height)
  const aspectX = Math.min(2.5, width / dim)
  const aspectY = Math.min(2.5, height / dim)
  const outlineEnabled = !shape && settings.rim > 0 && components === 4
  const edgeStep = Math.max(1, Math.round(dim * 0.024))
  const rgb = preview ? new Uint8Array(width * rows * 3) : null
  const maps = preview ? null : Array.from({length: 3}, () => new Uint8Array(width * rows * 4))
  const normal = { x: 0, y: 0, z: 1, depth: 0, opacity: 1 }
  const key = {}, fill = {}

  for (let y = start; y < start + rows; y++) {
    for (let x = 0; x < width; x++) {
      const index = (y * width + x) * components
      const out = (y - start) * width + x
      const coverage = alpha(source, x, y)
      const active = coverage && (!shape || (surface.sample(x, y, normal) && normal.opacity > 0))
      if (!active && !preview) continue
      const protection = settings.protectInk ? smooth(0.045, 0.25,
        Math.max(pixels[index], pixels[index + 1], pixels[index + 2]) / 255) : 1
      if (active && shape) {
        const length = Math.max(0.0001, Math.hypot(normal.x, normal.y, normal.z))
        normal.x /= length
        normal.y /= length
        normal.z /= length
        volumeLight(surface, lights[0], normal, x, y, dim, settings, key)
        volumeLight(surface, lights[1], normal, x, y, dim, settings, fill)
      } else if (active) {
        const edgeX = outlineEnabled ? alpha(source, x - edgeStep, y) - alpha(source, x + edgeStep, y) : 0
        const edgeY = outlineEnabled ? alpha(source, x, y - edgeStep) - alpha(source, x, y + edgeStep) : 0
        const u = (x + 0.5) / width
        const v = (y + 0.5) / height
        atmosphere(lights[0], u, v, aspectX, aspectY, edgeX, edgeY, settings, key)
        atmosphere(lights[1], u, v, aspectX, aspectY, edgeX, edgeY, settings, fill)
      }
      const ink = protection * (shape ? normal.opacity : 1)
      const keyAlpha = active ? lightOpacity(key) : 0
      const fillAlpha = active ? lightOpacity(fill) : 0
      const availableLight = clamp(keyAlpha + fillAlpha * (1 - keyAlpha))
      const shadowAlpha = active ? clamp((1 - availableLight) * settings.shadow * (shape ? 1 : 0.65)) : 0
      const checker = ((x >> 3) + (y >> 3)) % 2 ? 49 : 40
      const background = settings.backdrop ?? checker

      for (let c = 0; c < 3; c++) {
        const base = pixels[index + c]
        const dark = base * (0.17 + settings.shadowColor[c] / 255)
        const lit = channelLit(base, lights[0].color[c], key, keyAlpha, shape)
        const filled = channelLit(base, lights[1].color[c], fill, fillAlpha, shape)
        if (preview) {
          let color = base + (dark - base) * shadowAlpha * ink
          color += (lit - color) * keyAlpha * ink
          color += (filled - color) * fillAlpha * ink
          rgb[out * 3 + c] = Math.round(background + (color - background) * coverage)
        } else {
          if (shadowAlpha * ink > 0.002) maps[0][out * 4 + c] = Math.round(dark)
          if (keyAlpha * ink > 0.002) maps[1][out * 4 + c] = Math.round(lit)
          if (fillAlpha * ink > 0.002) maps[2][out * 4 + c] = Math.round(filled)
        }
      }
      if (!preview) {
        maps[0][out * 4 + 3] = Math.round(shadowAlpha * ink * 255)
        maps[1][out * 4 + 3] = Math.round(keyAlpha * ink * 255)
        maps[2][out * 4 + 3] = Math.round(fillAlpha * ink * 255)
      }
    }
  }
  return rgb || maps
}

module.exports = { render, shrink }
