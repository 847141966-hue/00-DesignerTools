const { app, constants, core, imaging } = require('photoshop')
const { render } = require('./lighting.js')

const colorOptions = { colorSpace: 'RGB', colorProfile: 'sRGB IEC61966-2.1' }
const MAX_PIXELS = 24_000_000

function selectedRaster() {
  if (!app.documents.length) throw new Error('请先打开一张画稿。')
  const doc = app.activeDocument
  if (doc.mode !== constants.DocumentMode.RGB || doc.bitsPerChannel !== constants.BitsPerChannelType.EIGHT) {
    throw new Error('请使用 RGB、8 位/通道的文档。')
  }
  const layers = doc.activeLayers
  if (layers.length !== 1 || layers[0].kind !== constants.LayerKind.NORMAL) {
    throw new Error('请选择一个像素图层。多图层画稿可先盖印到新图层。')
  }
  return { doc, layer: layers[0] }
}

function findLayer(layers, id) {
  for (const layer of layers) {
    if (layer.id === id) return layer
    if (layer.kind === constants.LayerKind.GROUP) {
      const match = findLayer(layer.layers, id)
      if (match) return match
    }
  }
}

function boundedRect(doc, layer, clip) {
  const bounds = layer.boundsNoEffects
  const left = Math.max(0, Math.floor(bounds.left), clip ? clip.left : 0)
  const top = Math.max(0, Math.floor(bounds.top), clip ? clip.top : 0)
  const right = Math.min(doc.width, Math.ceil(bounds.right), clip ? clip.left + clip.width : doc.width)
  const bottom = Math.min(doc.height, Math.ceil(bounds.bottom), clip ? clip.top + clip.height : doc.height)
  if (right <= left || bottom <= top) throw new Error('图层在画稿范围内没有像素。')
  if ((right - left) * (bottom - top) > MAX_PIXELS) {
    throw new Error('此版本最多处理 2400 万像素。可将需要打光的主体拆成多个图层。')
  }
  return { left, top, right, bottom }
}

async function readRaster(doc, layer, clip, rawChannels = false) {
  const sourceBounds = boundedRect(doc, layer, clip)
  const result = await imaging.getPixels({
    documentID: doc.id, layerID: layer.id, sourceBounds,
    ...(rawChannels ? { colorSpace: 'RGB' } : colorOptions), componentSize: 8, applyAlpha: false
  })
  const { imageData } = result
  try {
    const { width, height, components } = imageData
    if (!width || !height) throw new Error('所选图层没有可读取的像素。')
    const pixels = new Uint8Array(await imageData.getData({ chunky: true }))
    return { pixels, width, height, components, left: result.sourceBounds.left, top: result.sourceBounds.top }
  } finally {
    imageData.dispose()
  }
}

async function jpeg(buffer, raster) {
  const data = await imaging.createImageDataFromBuffer(buffer, {
    width: raster.width, height: raster.height, components: 3, ...colorOptions
  })
  try {
    return 'data:image/jpeg;base64,' + await imaging.encodeImageData({ imageData: data, base64: true })
  } finally {
    data.dispose()
  }
}

function hasPaint(map) {
  for (let i = 3; i < map.length; i += 4) {
    if (map[i]) return true
  }
  return false
}

async function writeTile(doc, layer, source, start, rows, map) {
  const data = await imaging.createImageDataFromBuffer(map, {
    width: source.width, height: rows, components: 4, ...colorOptions
  })
  try {
    await imaging.putPixels({
      documentID: doc.id, layerID: layer.id, imageData: data, replace: false,
      targetBounds: { left: source.left, top: source.top + start }
    })
  } finally {
    data.dispose()
  }
}

async function applyLighting(ref, settings) {
  const name = settings.mode === 'shape' ? '画光 · 立体打光' : '画光 · 成图补光'
  await core.executeAsModal(async context => {
    if (!app.documents.length || app.activeDocument.id !== ref.documentID) {
      throw new Error('请切回读取画稿时的 Photoshop 文档。')
    }
    const doc = app.activeDocument
    const base = findLayer(doc.layers, ref.layerID)
    if (!base) throw new Error('原画稿图层已移除，请重新读取。')
    if (base.isClippingMask) throw new Error('请选择剪贴组底部的基底图层，或使用盖印图层。')
    const source = await readRaster(doc, base)
    let guide = null
    if (settings.mode === 'shape') {
      if (ref.points) {
        if (ref.bounds && ['left', 'top', 'width', 'height'].some(key => ref.bounds[key] !== source[key])) {
          throw new Error('画稿图层的范围已变化。请重新读取并对齐头像。')
        }
        guide = { kind: 'face', points: ref.points }
      } else {
        const layer = findLayer(doc.layers, ref.guideID)
        if (!layer) throw new Error('请对齐头像或重新读取形体图层。')
        guide = { ...await readRaster(doc, layer, source, ref.guideKind === 'normal'), kind: ref.guideKind }
      }
    }

    const history = await context.hostControl.suspendHistory({ documentID: doc.id, name })
    if (history === 0xffffffff) throw new Error('请等待 Photoshop 当前动作完成后再写入。')
    try {
      const group = await doc.createLayerGroup({ name, blendMode: constants.BlendMode.NORMAL })
      group.move(base, constants.ElementPlacement.PLACEBEFORE)
      if (!base.isBackgroundLayer) group.isClippingMask = true
      const names = ['阴影', '主光', '辅光']
      const layers = [null, null, null]
      const tileHeight = Math.min(128, Math.max(1, Math.floor(524288 / source.width)))
      for (let y = 0; y < source.height; y += tileHeight) {
        if (context.isCancelled) throw new Error('已取消写入。')
        const rows = Math.min(tileHeight, source.height - y)
        const maps = render(source, guide, settings, { start: y, rows })
        for (let i = 0; i < maps.length; i++) {
          if (!hasPaint(maps[i])) continue
          if (!layers[i]) {
            const layer = await doc.createLayer(constants.LayerKind.NORMAL, { name: names[i] })
            const next = layers.slice(i + 1).find(Boolean)
            const previous = layers.slice(0, i).reverse().find(Boolean)
            if (next) layer.move(next, constants.ElementPlacement.PLACEAFTER)
            else if (previous) layer.move(previous, constants.ElementPlacement.PLACEBEFORE)
            else layer.move(group, constants.ElementPlacement.PLACEINSIDE)
            layers[i] = layer
          }
          await writeTile(doc, layers[i], source, y, rows, maps[i])
        }
        context.reportProgress({ value: (y + rows) / source.height })
      }
      if (!layers.some(Boolean)) throw new Error('当前设置没有产生可写入的光影。')
    } catch (error) {
      await context.hostControl.resumeHistory(history, false)
      throw error
    }
    await context.hostControl.resumeHistory(history, true)
  }, { commandName: name })
}

module.exports = { selectedRaster, readRaster, jpeg, applyLighting }
