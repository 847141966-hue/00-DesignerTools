const { shrink } = require('./lighting.js')

function quantile(values, fraction) {
  values.sort((a, b) => a - b)
  return values[Math.floor((values.length - 1) * fraction)]
}

function transparentMask(image) {
  if (image.components !== 4) return null
  const mask = new Uint8Array(image.width * image.height)
  let transparent = 0
  let opaque = 0
  for (let i = 0; i < mask.length; i++) {
    const value = image.pixels[i * 4 + 3]
    mask[i] = value >= 64 ? 1 : 0
    if (value < 64) transparent++
    if (value >= 192) opaque++
  }
  return transparent > mask.length * 0.012 && opaque > mask.length * 0.01 ? mask : null
}

function paperMask(image) {
  const { width, height, components, pixels } = image
  const margin = []
  for (let x = 0; x < width; x += 2) margin.push(x, (height - 1) * width + x)
  for (let y = 1; y < height - 1; y += 2) margin.push(y * width, y * width + width - 1)
  const paper = [0, 1, 2].map(c => quantile(margin.map(i => pixels[i * components + c]), 0.5))
  function difference(i) {
    const p = i * components
    return Math.max(
      Math.abs(pixels[p] - paper[0]),
      Math.abs(pixels[p + 1] - paper[1]),
      Math.abs(pixels[p + 2] - paper[2])
    )
  }
  const edgeContrast = quantile(margin.map(difference), 0.67)
  if (edgeContrast > 22) return null

  const wall = new Uint8Array(width * height)
  const threshold = Math.max(10, edgeContrast * 2 + 6)
  for (let i = 0; i < wall.length; i++) wall[i] = difference(i) > threshold ? 1 : 0

  // Close one-pixel breaks in an outline before filling outward from the paper.
  const outside = new Uint8Array(wall.length)
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const i = y * width + x
      if (wall[i] || (wall[i - 1] && wall[i + 1]) || (wall[i - width] && wall[i + width])) outside[i] = 1
    }
  }
  for (let x = 0; x < width; x++) {
    outside[x] = wall[x]
    const bottom = (height - 1) * width + x
    outside[bottom] = wall[bottom]
  }
  for (let y = 1; y < height - 1; y++) {
    const left = y * width
    const right = left + width - 1
    outside[left] = wall[left]
    outside[right] = wall[right]
  }

  const queue = new Int32Array(wall.length)
  let end = 0
  function visit(i) {
    if (outside[i]) return
    outside[i] = 2
    queue[end++] = i
  }
  for (let x = 0; x < width; x++) {
    visit(x)
    visit((height - 1) * width + x)
  }
  for (let y = 1; y < height - 1; y++) {
    visit(y * width)
    visit(y * width + width - 1)
  }
  for (let head = 0; head < end; head++) {
    const i = queue[head]
    if (i % width > 0) visit(i - 1)
    if (i % width < width - 1) visit(i + 1)
    if (i >= width) visit(i - width)
    if (i < wall.length - width) visit(i + width)
  }
  if (end < wall.length * 0.055 || end > wall.length * 0.985) return null
  for (let i = 0; i < wall.length; i++) wall[i] = outside[i] === 2 ? 0 : 1
  return wall
}

function distanceField(mask, width, height) {
  const distance = new Float32Array(mask.length)
  for (let i = 0; i < mask.length; i++) distance[i] = mask[i] ? width + height : 0
  const diagonal = Math.SQRT2
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x
      if (!mask[i]) continue
      const left = x ? distance[i - 1] : 0
      const up = y ? distance[i - width] : 0
      const upperLeft = x && y ? distance[i - width - 1] : 0
      const upperRight = x + 1 < width && y ? distance[i - width + 1] : 0
      distance[i] = Math.min(left + 1, up + 1, upperLeft + diagonal, upperRight + diagonal)
    }
  }
  for (let y = height - 1; y >= 0; y--) {
    for (let x = width - 1; x >= 0; x--) {
      const i = y * width + x
      if (!mask[i]) continue
      const right = x + 1 < width ? distance[i + 1] : 0
      const down = y + 1 < height ? distance[i + width] : 0
      const lowerRight = x + 1 < width && y + 1 < height ? distance[i + width + 1] : 0
      const lowerLeft = x && y + 1 < height ? distance[i + width - 1] : 0
      distance[i] = Math.min(distance[i], right + 1, down + 1, lowerRight + diagonal, lowerLeft + diagonal)
    }
  }
  return distance
}

function smoothField(field, width, height, radius) {
  const result = new Float32Array(field.length)
  const row = new Float32Array(field.length)
  const divisor = radius * 2 + 1
  for (let y = 0; y < height; y++) {
    const start = y * width
    let sum = 0
    for (let x = 0; x < radius; x++) sum += field[start + x]
    for (let x = 0; x < width; x++) {
      if (x + radius < width) sum += field[start + x + radius]
      if (x - radius - 1 >= 0) sum -= field[start + x - radius - 1]
      row[start + x] = sum / divisor
    }
  }
  for (let x = 0; x < width; x++) {
    let sum = 0
    for (let y = 0; y < radius; y++) sum += row[y * width + x]
    for (let y = 0; y < height; y++) {
      if (y + radius < height) sum += row[(y + radius) * width + x]
      if (y - radius - 1 >= 0) sum -= row[(y - radius - 1) * width + x]
      result[y * width + x] = sum / divisor
    }
  }
  return result
}

function automaticGuide(source) {
  const image = shrink(source, Math.min(1, 256 / Math.max(source.width, source.height)))
  const { width, height } = image
  const dim = Math.min(width, height)
  if (dim < 8) return null
  const mask = transparentMask(image) || paperMask(image)
  if (!mask) return null
  const distance = distanceField(mask, width, height)
  let max = 0
  for (const value of distance) max = Math.max(max, value)
  if (max < Math.max(2.4, dim * 0.018)) return null
  for (let i = 0; i < distance.length; i++) {
    distance[i] = distance[i] < 1 ? 0 : Math.sqrt(distance[i] / max) * max
  }
  const radius = Math.max(1, Math.round(dim * 0.035))
  const first = smoothField(distance, width, height, radius)
  const heights = smoothField(first, width, height, radius)
  return { kind: 'automatic', width, height, mask, heights }
}

module.exports = { automaticGuide }
