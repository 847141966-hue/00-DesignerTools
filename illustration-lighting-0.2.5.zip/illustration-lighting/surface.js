const model = require('./assets/face-data.js')

const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n))
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
let mesh
let feather

function faceMesh() {
  if (!mesh) {
    mesh = new Uint8Array(model.width * model.height * 4)
    for (let i = 0, dest = 0; dest < mesh.length; i += 4) {
      const code = (alphabet.indexOf(model.data[i]) << 18) |
        (alphabet.indexOf(model.data[i + 1]) << 12) |
        (Math.max(0, alphabet.indexOf(model.data[i + 2])) << 6) |
        Math.max(0, alphabet.indexOf(model.data[i + 3]))
      mesh[dest++] = code >> 16
      if (dest < mesh.length) mesh[dest++] = code >> 8
      if (dest < mesh.length) mesh[dest++] = code
    }
  }
  return mesh
}

function faceFeather() {
  if (feather) return feather
  const pixels = faceMesh()
  const { width, height } = model
  feather = new Uint8Array(width * height)
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x
      if (!pixels[i * 4 + 3]) continue
      const west = x ? feather[i - 1] : 0
      const north = y ? feather[i - width] : 0
      feather[i] = Math.min(8, west + 1, north + 1)
    }
  }
  for (let y = height - 1; y >= 0; y--) {
    for (let x = width - 1; x >= 0; x--) {
      const i = y * width + x
      const east = x + 1 < width ? feather[i + 1] : 0
      const south = y + 1 < height ? feather[i + width] : 0
      feather[i] = Math.min(feather[i], east + 1, south + 1)
    }
  }
  return feather
}

function spherePreview() {
  const size = 288
  const center = size / 2
  const radius = size * 0.34
  const pixels = new Uint8Array(size * size * 4)
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const coverage = clamp(radius + 0.5 - Math.hypot(x + 0.5 - center, y + 0.5 - center), 0, 1)
      if (!coverage) continue
      const i = (y * size + x) * 4
      pixels[i] = 170
      pixels[i + 1] = 170
      pixels[i + 2] = 170
      pixels[i + 3] = Math.round(coverage * 255)
    }
  }
  return {
    raster: { width: size, height: size, components: 4, pixels, left: 0, top: 0 },
    guide: { kind: 'sphere', center, radius }
  }
}

function sphereSurface({ center, radius }) {
  return {
    sample(x, y, out) {
      out.x = (x + 0.5 - center) / radius
      out.y = (y + 0.5 - center) / radius
      out.z = Math.sqrt(Math.max(0, 1 - out.x * out.x - out.y * out.y))
      out.opacity = 1
      return true
    }
  }
}

function offset(image, x, y) {
  if (x < 0 || x >= image.width || y < 0 || y >= image.height) return -1
  const i = (y * image.width + x) * image.components
  if (image.components === 4 && image.pixels[i + 3] < 16) return -1
  return i
}

function faceSurface(source, points, relief, maskSkin) {
  const pixels = faceMesh()
  const edge = faceFeather()
  const [[lx, ly], [rx, ry], [cx, cy]] = points.map(([x, y]) => [x * source.width, y * source.height])
  const [p, q, r] = model.landmarks
  const ux = (rx - lx) / (q[0] - p[0])
  const uy = (ry - ly) / (q[0] - p[0])
  const vx = (cx - (lx + rx) / 2) / (r[1] - p[1])
  const vy = (cy - (ly + ry) / 2) / (r[1] - p[1])
  const det = ux * vy - uy * vx
  if (det < source.width * source.height * 0.000001) {
    throw new Error('请依序点击画面左眼、右眼和下巴底部，三个点需要围成三角形。')
  }
  const a = vy / det, b = -vx / det, c = -uy / det, d = ux / det
  const zScale = Math.sqrt(det) * (0.35 + relief)
  const depthSpan = model.depthSpan * zScale
  const skin = maskSkin ? referencePigment(source, lx, ly, ux, uy, vx, vy, p) : null
  function index(u, v) {
    if (u < 0 || u >= model.width || v < 0 || v >= model.height) return -1
    const i = (v * model.width + u) * 4
    return pixels[i + 3] ? i : -1
  }
  return {
    depthAt(x, y) {
      const i = index(Math.floor(p[0] + a * (x - lx) + b * (y - ly)),
        Math.floor(p[1] + c * (x - lx) + d * (y - ly)))
      return i < 0 ? NaN : (pixels[i + 3] - 1) * depthSpan / 254
    },
    sample(x, y, out) {
      const u = p[0] + a * (x + 0.5 - lx) + b * (y + 0.5 - ly) - 0.5
      const v = p[1] + c * (x + 0.5 - lx) + d * (y + 0.5 - ly) - 0.5
      const ix = Math.floor(u), iy = Math.floor(v)
      const i = index(Math.round(u), Math.round(v))
      if (i < 0) return false
      const p00 = index(ix, iy), p01 = index(ix + 1, iy)
      const p10 = index(ix, iy + 1), p11 = index(ix + 1, iy + 1)
      const du = u - ix, dv = v - iy
      const a00 = p00 < 0 ? i : p00, a01 = p01 < 0 ? i : p01
      const a10 = p10 < 0 ? i : p10, a11 = p11 < 0 ? i : p11
      const w00 = (1 - du) * (1 - dv), w01 = du * (1 - dv)
      const w10 = (1 - du) * dv, w11 = du * dv
      const nx = blendChannel(pixels, a00, a01, a10, a11, w00, w01, w10, w11) * (2 / 255) - 1
      const ny = blendChannel(pixels, a00+1, a01+1, a10+1, a11+1, w00, w01, w10, w11) * (2 / 255) - 1
      out.x = (a * nx + c * ny) * zScale
      out.y = (b * nx + d * ny) * zScale
      out.z = blendChannel(pixels, a00+2, a01+2, a10+2, a11+2, w00, w01, w10, w11) * (2 / 255) - 1
      out.depth = (blendChannel(pixels, a00+3, a01+3, a10+3, a11+3, w00, w01, w10, w11) - 1) * depthSpan / 254
      out.opacity = source.width === model.width && source.height === model.height ?
        1 : Math.min(1, edge[i / 4] / 5)
      if (skin) out.opacity *= pigmentMask(source, x, y, skin)
      return true
    }
  }
}

function blendChannel(data, a, b, c, d, wa, wb, wc, wd) {
  return data[a] * wa + data[b] * wb + data[c] * wc + data[d] * wd
}

function referencePigment(source, lx, ly, ux, uy, vx, vy, anchor) {
  const samples = []
  for (const v of [0.49, 0.54, 0.59, 0.65]) {
    for (const u of [0.33, 0.4, 0.5, 0.6, 0.67]) {
      const dx = model.width * u - anchor[0]
      const dy = model.height * v - anchor[1]
      const i = offset(source, Math.floor(lx + ux * dx + vx * dy),
        Math.floor(ly + uy * dx + vy * dy))
      if (i >= 0) samples.push(source.pixels.subarray(i, i + 3))
    }
  }
  if (!samples.length) return null
  return [0, 1, 2].map(channel => {
    const values = samples.map(p => p[channel]).sort((a, b) => a - b)
    return values[Math.floor(values.length / 2)]
  })
}

function pigmentMask(source, x, y, pigment) {
  const i = (y * source.width + x) * source.components
  const dr = source.pixels[i] - pigment[0]
  const dg = source.pixels[i+1] - pigment[1]
  const db = source.pixels[i+2] - pigment[2]
  const chroma = Math.hypot(dr - dg, db - dg)
  const brightness = Math.abs(0.3 * dr + 0.6 * dg + 0.1 * db)
  const t = clamp((Math.hypot(chroma * .62, brightness) - 23) / 55, 0, 1)
  return 1 - t*t*(3 - 2*t)
}

function imageSurface(source, guide, relief) {
  const shiftX = source.left - guide.left
  const shiftY = source.top - guide.top
  const dim = Math.min(source.width, source.height)
  const heightScale = dim * relief * 0.38
  const radius = Math.max(2, Math.round(dim * 0.012))
  function rgbOffset(x, y) {
    return offset(guide, Math.floor(x + shiftX), Math.floor(y + shiftY))
  }
  function depthAt(x, y) {
    const i = rgbOffset(x, y)
    if (i < 0) return NaN
    const p = guide.pixels
    return (p[i] * 0.2126 + p[i + 1] * 0.7152 + p[i + 2] * 0.0722) * heightScale / 255
  }
  function difference(x, y, dx, dy, center) {
    const low = depthAt(x - dx, y - dy)
    const high = depthAt(x + dx, y + dy)
    return ((Number.isNaN(low) ? center : low) - (Number.isNaN(high) ? center : high)) / (radius * 2)
  }
  return {
    depthAt: guide.kind === 'normal' ? null : depthAt,
    sample(x, y, out) {
      const i = rgbOffset(x, y)
      if (i < 0) return false
      out.opacity = guide.components === 4 ? guide.pixels[i + 3] / 255 : 1
      if (guide.kind === 'normal') {
        out.x = (guide.pixels[i] * (2 / 255) - 1) * relief * 1.6
        out.y = (1 - guide.pixels[i + 1] * (2 / 255)) * relief * 1.6
        out.z = Math.max(0.02, guide.pixels[i + 2] * (2 / 255) - 1)
      } else {
        const center = depthAt(x, y)
        out.x = difference(x, y, radius, 0, center)
        out.y = difference(x, y, 0, radius, center)
        out.z = 1
        out.depth = center
      }
      return true
    }
  }
}

function automaticSurface(source, guide, relief) {
  const { width, height, heights, mask } = guide
  const scaleX = width / source.width
  const scaleY = height / source.height
  const depthScale = relief * 1.48 / Math.max(scaleX, scaleY)
  const step = Math.max(1, Math.min(source.width / width, source.height / height))
  const heightStep = depthScale / (step * 2)

  function interpolate(field, x, y) {
    const u = clamp((x + 0.5) * scaleX - 0.5, 0, width - 1)
    const v = clamp((y + 0.5) * scaleY - 0.5, 0, height - 1)
    const ix = Math.min(width - 2, Math.floor(u))
    const iy = Math.min(height - 2, Math.floor(v))
    const i = iy * width + ix
    const dx = u - ix
    const dy = v - iy
    const top = field[i] * (1 - dx) + field[i + 1] * dx
    const bottom = field[i + width] * (1 - dx) + field[i + width + 1] * dx
    return top * (1 - dy) + bottom * dy
  }

  return {
    depthAt(x, y) {
      if (x < 0 || x >= source.width || y < 0 || y >= source.height || interpolate(mask, x, y) < 0.5) return NaN
      return interpolate(heights, x, y) * depthScale
    },
    sample(x, y, out) {
      const coverage = interpolate(mask, x, y)
      if (coverage < 0.5) return false
      out.x = (interpolate(heights, x - step, y) - interpolate(heights, x + step, y)) * heightStep
      out.y = (interpolate(heights, x, y - step) - interpolate(heights, x, y + step)) * heightStep
      out.z = 1
      out.depth = interpolate(heights, x, y) * depthScale
      out.opacity = (coverage - 0.5) * 2
      return true
    }
  }
}

function prepareSurface(source, guide, relief, maskSkin = false) {
  if (guide.kind === 'sphere') return sphereSurface(guide)
  if (guide.kind === 'face') return faceSurface(source, guide.points, relief, maskSkin)
  if (guide.kind === 'automatic') return automaticSurface(source, guide, relief)
  return imageSurface(source, guide, relief)
}

function visibility(surface, normal, light, x, y, dim, softness) {
  if (!surface.depthAt || light.z <= 0 || light.horizontal < 0.02) return 1
  // Test rays in the exported height field. Increasing steps stays cheap on large drawings.
  const dx = light.x / light.horizontal
  const dy = light.y / light.horizontal
  const slope = light.z / light.horizontal
  const minStep = Math.max(1.5, dim * 0.012)
  const bias = Math.max(1.15, dim * 0.004)
  let blocker = 0
  for (let tap = 1, step = minStep; tap <= 7; tap++, step *= 1.58) {
    const height = surface.depthAt(x + dx * step, y + dy * step)
    if (Number.isNaN(height)) continue
    const gap = height - normal.depth - slope * step - bias
    blocker = Math.max(blocker, gap / (bias + step * (0.04 + softness * 0.18)))
    if (blocker >= 1) break
  }
  return 1 - clamp(blocker, 0, 1)
}

module.exports = { prepareSurface, visibility, spherePreview }
