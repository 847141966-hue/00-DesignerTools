const { readSelectedRaster, jpeg, applyLighting } = require('./photoshop.js')
const { render, shrink } = require('./lighting.js')
const { automaticGuide } = require('./automatic-guide.js')
const { spherePreview, prepareSurface } = require('./surface.js')

const $ = id => document.getElementById(id)
const lights = [
  { x: 0.18, y: 0.21, depth: 0.72, strength: 0.77, color: [255, 250, 244] },
  { x: 0.91, y: 0.61, depth: 0.48, strength: 0.27, color: [226, 238, 255] }
]
const sphere = spherePreview()
const fitLabels = ['点击画面左侧的瞳孔中心。', '点击画面右侧的瞳孔中心。', '点击下巴最底端。']
let source = null
let guide = null
let sourceRef = null
let scale = 1
let mode = 'mood'
let activeLight = 0
let before = false
let fitting = null
let busy = false
let dragImage = null
let revision = 0
let timer = null
let encoding = false

function number(id) {
  return Number($(id).value) / 100
}

function settings() {
  return {
    mode: mode === 'shape' && !guide ? 'mood' : mode,
    lights: lights.map(light => ({ ...light })),
    softness: number('softness'),
    shadow: number('shadow'),
    rim: number('rim'),
    relief: number('relief'),
    gloss: number('gloss'),
    protectInk: $('protectInk').checked,
    maskSkin: $('maskSkin').checked
  }
}

function status(message, isError = false) {
  $('status').textContent = message
  $('status').className = message ? (isError ? 'error' : '') : 'hidden'
}

function refreshButtons() {
  $('apply').disabled = busy || !source || Boolean(fitting)
  $('guide').disabled = busy || !source
  $('normal').disabled = busy || !source
  $('alignFace').disabled = busy || !source
  $('alignFace').textContent = fitting ? '取消对齐' : '对齐头像'
  $('stageHint').textContent = fitting ? fitLabels[fitting.length] :
    before ? '当前显示原稿。点击「看打光」返回实时预览。' :
    '在灯光球上拖动灯位，画稿会同步预览。'
  $('load').disabled = busy
  $('compare').disabled = !source || Boolean(fitting)
  $('artFrame').className = source ? 'frame art-frame' : 'frame art-frame hidden'
  $('previews').className = source ? 'previews with-art' : 'previews'
  $('sourceName').textContent = sourceRef?.name || ''
}

function sizeImage(stage, image, raster) {
  const { width: stageWidth, height: stageHeight } = stage.getBoundingClientRect()
  const zoom = Math.min(stageWidth / raster.width, stageHeight / raster.height)
  const width = raster.width * zoom
  const height = raster.height * zoom
  const left = (stageWidth - width) / 2
  const top = (stageHeight - height) / 2
  image.style.display = 'block'
  image.style.width = width + 'px'
  image.style.height = height + 'px'
  image.style.left = left + 'px'
  image.style.top = top + 'px'
  return { left, top, width, height }
}

function layout() {
  const ball = sizeImage($('sphereStage'), $('sphereImage'), sphere.raster)
  for (const [i, id] of ['keyDot', 'fillDot'].entries()) {
    const light = lights[i]
    const marker = $(id)
    marker.style.display = 'block'
    marker.style.left = ball.left + 11 + light.x * Math.max(1, ball.width - 22) + 'px'
    marker.style.top = ball.top + 11 + light.y * Math.max(1, ball.height - 22) + 'px'
    marker.style.backgroundColor = hex(light.color)
    marker.className = i === activeLight ? 'marker' : 'marker inactive'
  }

  if (!source) return
  const art = sizeImage($('artStage'), $('artImage'), source)
  for (let i = 0; i < 3; i++) {
    const marker = $('fit' + i)
    const point = fitting && fitting[i]
    marker.style.display = point ? 'block' : 'none'
    if (point) {
      marker.style.left = art.left + art.width * point[0] + 'px'
      marker.style.top = art.top + art.height * point[1] + 'px'
    }
  }
}

function updatePreview() {
  revision++
  layout()
  schedulePreview()
}

function schedulePreview() {
  if (encoding || timer !== null) return
  // Keep one scheduled frame, even while pointer events keep arriving.
  timer = setTimeout(() => {
    timer = null
    drawPreview()
  }, 16)
}

async function drawPreview() {
  const target = revision
  const artwork = source
  const artGuide = guide
  const config = settings()
  encoding = true
  try {
    const sphereSettings = { ...config, mode: 'shape', backdrop: 31 }
    const spherePixels = render(sphere.raster, sphere.guide, sphereSettings, { preview: true })
    let artPixels
    if (artwork) {
      const showOriginal = before || fitting
      const artSettings = showOriginal ? {
        ...config, mode: 'mood', shadow: 0,
        lights: config.lights.map(light => ({ ...light, strength: 0 }))
      } : config
      artPixels = render(artwork, artGuide, artSettings, { preview: true })
    }

    const [sphereUrl, artUrl] = await Promise.all([
      jpeg(spherePixels, sphere.raster),
      artPixels ? jpeg(artPixels, artwork) : null
    ])
    // A finished frame is still useful during drag. Keep its two previews in sync.
    $('sphereImage').src = sphereUrl
    if (artUrl && artwork === source) $('artImage').src = artUrl
  } catch (error) {
    if (target === revision) status(error.message || String(error), true)
  } finally {
    encoding = false
    if (target !== revision) schedulePreview()
  }
}

async function run(task) {
  if (busy) return
  busy = true
  refreshButtons()
  try {
    await task()
  } catch (error) {
    status(error.message || String(error), true)
  } finally {
    busy = false
    refreshButtons()
  }
}

$('load').addEventListener('click', () => run(async () => {
  const { documentID, layerID, name, raster } = await readSelectedRaster()
  sourceRef = {
    documentID, layerID, name,
    bounds: { left: raster.left, top: raster.top, width: raster.width, height: raster.height }
  }
  scale = Math.min(1, 420 / Math.max(raster.width, raster.height))
  source = shrink(raster, scale)
  guide = automaticGuide(raster)
  fitting = null
  before = false
  $('compare').textContent = '看原稿'
  const shapeDetails = guide?.segmented ? '已按色块和轮廓粗估转面。' : '已根据轮廓粗估体积。'
  $('guideLabel').textContent = guide ? shapeDetails + ' 可读高度或法线控制细节。' :
    '未识别到清晰轮廓，当前预览成图补光。读高度、读法线或对齐头像后可立体打光。'
  status('')
  refreshButtons()
  updatePreview()
}))

function loadSurface(kind) {
  return run(async () => {
    const { layerID, name, raster } = await readSelectedRaster(sourceRef, kind)
    guide = { ...shrink(raster, scale), kind }
    sourceRef.guideID = layerID
    sourceRef.guideKind = kind
    sourceRef.points = null
    fitting = null
    before = false
    $('compare').textContent = '看原稿'
    $('guideLabel').textContent = (kind === 'normal' ? '法线图：' : '高度图：') + name
    status('预览已更新。写入前可隐藏形体图层。')
    refreshButtons()
    updatePreview()
  })
}

$('guide').addEventListener('click', () => loadSurface('height'))
$('normal').addEventListener('click', () => loadSurface('normal'))

$('alignFace').addEventListener('click', () => {
  fitting = fitting ? null : []
  status(fitting ? fitLabels[0] : '')
  refreshButtons()
  updatePreview()
})

$('apply').addEventListener('click', () => run(async () => {
  status('正在写入光影…')
  await applyLighting({ ...sourceRef }, settings())
  status('已写入打光组。可分别调节、擦除或隐藏。')
}))

for (const next of ['mood', 'shape']) {
  $(next).addEventListener('click', () => {
    mode = next
    fitting = null
    before = false
    $('compare').textContent = '看原稿'
    $('mood').setAttribute('variant', mode === 'mood' ? 'primary' : 'secondary')
    $('shape').setAttribute('variant', mode === 'shape' ? 'primary' : 'secondary')
    $('guideControls').className = mode === 'shape' ? 'guide' : 'guide hidden'
    $('relief').className = mode === 'shape' ? '' : 'hidden'
    $('gloss').className = mode === 'shape' ? '' : 'hidden'
    $('lightDepth').className = mode === 'shape' ? '' : 'hidden'
    refreshButtons()
    updatePreview()
  })
}

$('compare').addEventListener('click', () => {
  before = !before
  $('compare').textContent = before ? '看打光' : '看原稿'
  refreshButtons()
  updatePreview()
})

function hex(rgb) {
  return '#' + rgb.map(value => value.toString(16).padStart(2, '0')).join('').toUpperCase()
}

function syncPosition() {
  $('lightX').value = Math.round(lights[activeLight].x * 100)
  $('lightY').value = Math.round(lights[activeLight].y * 100)
  $('lightDepth').value = Math.round(lights[activeLight].depth * 100)
}

function selectLight(index) {
  activeLight = index
  $('key').setAttribute('variant', index === 0 ? 'primary' : 'secondary')
  $('fill').setAttribute('variant', index === 1 ? 'primary' : 'secondary')
  $('color').value = hex(lights[index].color)
  $('swatch').style.backgroundColor = $('color').value
  $('strength').value = Math.round(lights[index].strength * 100)
  syncPosition()
  layout()
}

$('key').addEventListener('click', () => selectLight(0))
$('fill').addEventListener('click', () => selectLight(1))
$('color').addEventListener('input', () => {
  const value = $('color').value.trim()
  if (!/^#[\da-f]{6}$/i.test(value)) return
  lights[activeLight].color = [1, 3, 5].map(i => parseInt(value.slice(i, i + 2), 16))
  $('swatch').style.backgroundColor = value
  updatePreview()
})
$('color').addEventListener('change', () => { $('color').value = hex(lights[activeLight].color) })

for (const [id, property] of [['strength', 'strength'], ['lightX', 'x'], ['lightY', 'y'], ['lightDepth', 'depth']]) {
  const refreshLight = () => {
    lights[activeLight][property] = number(id)
    updatePreview()
  }
  $(id).addEventListener('input', refreshLight)
  $(id).addEventListener('change', refreshLight)
}
for (const id of ['softness', 'shadow', 'rim', 'relief', 'gloss']) {
  $(id).addEventListener('input', updatePreview)
  $(id).addEventListener('change', updatePreview)
}
for (const id of ['protectInk', 'maskSkin']) $(id).addEventListener('change', updatePreview)

function position(event, image, inset = 0) {
  const rect = image.getBoundingClientRect()
  return [
    (event.clientX - rect.left - inset) / Math.max(1, rect.width - 2 * inset),
    (event.clientY - rect.top - inset) / Math.max(1, rect.height - 2 * inset)
  ]
}

function placeLight(event, image) {
  const [x, y] = position(event, image, 11).map(value => Math.max(0, Math.min(1, value)))
  lights[activeLight].x = x
  lights[activeLight].y = y
  syncPosition()
  updatePreview()
}

function fitPoint(event) {
  const point = position(event, $('artImage'))
  if (point.some(value => value < 0 || value > 1)) return
  fitting.push(point)
  if (fitting.length < 3) {
    status(fitLabels[fitting.length])
  } else {
    const candidate = { kind: 'face', points: fitting }
    try {
      prepareSurface(source, candidate, 0.65)
      guide = candidate
      sourceRef.points = fitting
      before = false
      $('compare').textContent = '看原稿'
      $('guideLabel').textContent = '已对齐正面头像。'
      status('可调整灯位查看鼻梁、眼窝和下颌的转面。')
    } catch (error) {
      status(error.message, true)
    }
    fitting = null
  }
  refreshButtons()
  updatePreview()
}

for (const [stage, image] of [[$('sphereStage'), $('sphereImage')], [$('artStage'), $('artImage')]]) {
  stage.addEventListener('pointerdown', event => {
    if (image.id === 'artImage') {
      if (fitting) return fitPoint(event)
      if (before) return
    }
    if (event.target.id === 'keyDot') selectLight(0)
    if (event.target.id === 'fillDot') selectLight(1)
    dragImage = image
    placeLight(event, image)
    event.preventDefault()
  })
  stage.addEventListener('pointermove', event => {
    if (dragImage === image) placeLight(event, image)
  })
  for (const type of ['pointerup', 'pointercancel', 'pointerleave']) {
    stage.addEventListener(type, () => { dragImage = null })
  }
}
window.addEventListener('resize', layout)
selectLight(0)
refreshButtons()
updatePreview()
